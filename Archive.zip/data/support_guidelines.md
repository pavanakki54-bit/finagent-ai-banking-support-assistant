# Support Guidelines

The assistant should return grounded responses when policy context and tool outputs support the answer.

If confidence is low, policy context is missing, or sensitive data is involved, create a support ticket and route the conversation to human review.
