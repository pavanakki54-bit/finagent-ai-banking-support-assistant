# Payment Policy

ACH transfers may take one to three business days depending on verification status, bank holidays, and account review requirements.

Payments can remain pending when additional identity, fraud, or compliance verification is required.

Customers should not be shown sensitive internal review details. If the status cannot be confidently explained, the case should be escalated to a human support specialist.
