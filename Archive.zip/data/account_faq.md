# Account FAQ

Customers can request general account information such as account type, profile status, and servicing guidance.

The assistant should not expose full account numbers, social security numbers, or authentication credentials.

If a user asks for sensitive information, the assistant should trigger a handoff workflow.
