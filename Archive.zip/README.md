# FinAgent AI — Agentic Banking Support Assistant

A portfolio-safe Agentic AI banking support assistant demonstrating Generative AI, RAG, LangGraph-style orchestration, secure tool calling, verification guardrails, and human handoff workflows for financial-services support scenarios.

> This project uses only synthetic data and generic financial workflows. It does not include proprietary client data, internal documents, or real banking APIs.

## Key Features

- React chat UI for customer support questions
- FastAPI backend with `/chat`, `/health`, and `/tickets` endpoints
- Intent detection for payment, account, eligibility, policy, and escalation requests
- RAG pipeline over synthetic banking policy documents
- FAISS-ready/vector-store abstraction with fallback in-memory retrieval
- Mock banking tools for account, payment, eligibility, and support tickets
- Guardrails for PII checks, grounding checks, confidence scoring, and escalation
- Docker and docker-compose setup
- Evaluation script for sample RAG/intent test cases

## Architecture Summary

```text
User → React UI → FastAPI Backend → Agent Orchestrator
                                  ├── Intent Detection
                                  ├── RAG Retriever → Policy Docs / Vector Store
                                  ├── Mock Banking Tools → Synthetic JSON Data
                                  ├── LLM Response Service
                                  └── Guardrails → Answer or Human Handoff
```

## Example Scenario

User asks: `Why is my ACH payment delayed?`

1. FastAPI receives the chat request.
2. Agent detects `payment_inquiry` intent.
3. RAG retrieves relevant ACH/payment policy context.
4. Payment tool checks mock payment status.
5. LLM service creates a grounded response from policy + tool data.
6. Guardrails verify confidence, grounding, and sensitive data safety.
7. System returns an answer or creates a support ticket.

## Tech Stack

- Frontend: React, TypeScript
- Backend: Python, FastAPI
- Agentic Workflow: LangGraph-style state orchestration
- RAG: LangChain-style document retrieval, FAISS-ready design
- LLM Layer: OpenAI/Claude/Bedrock-compatible service abstraction
- Data: Synthetic markdown policies and JSON mock data
- DevOps: Docker, docker-compose

## Run Locally

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

### Docker Compose

```bash
docker-compose up --build
```

Frontend: http://localhost:3000  
Backend API docs: http://localhost:8000/docs

## Suggested GitHub Topics

`generative-ai`, `agentic-ai`, `rag`, `langgraph`, `langchain`, `fastapi`, `react`, `fintech`, `llmops`, `vector-search`, `ai-engineering`
