import json
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1] / "backend"))
from app.agents.banking_agent import detect_intent

questions = json.loads((Path(__file__).parent / "test_questions.json").read_text())
expected = json.loads((Path(__file__).parent / "expected_answers.json").read_text())

passed = 0
for q, exp in zip(questions, expected):
    actual = detect_intent(q)
    ok = actual == exp["intent"]
    passed += int(ok)
    print({"question": q, "expected": exp["intent"], "actual": actual, "passed": ok})

print({"passed": passed, "total": len(questions)})
