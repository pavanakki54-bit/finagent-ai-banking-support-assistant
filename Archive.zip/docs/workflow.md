# Workflow Details

## 1. Intent Detection

Classifies the user request into payment inquiry, account question, eligibility check, policy FAQ, or human support.

## 2. Retrieval-Augmented Generation

Loads synthetic banking documents, chunks them, indexes them, and retrieves relevant policy context for the user query.

## 3. Tool Calling

Uses mock business tools for account summaries, payment status, customer verification, eligibility checks, and support ticket creation.

## 4. Verification

Runs grounding, confidence, and PII checks before returning the response.

## 5. Human Handoff

Creates a support ticket when confidence is low, data is sensitive, or human review is required.
