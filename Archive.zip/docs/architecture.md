# Architecture — FinAgent AI

## End-to-End System

```text
┌────────────────────┐
│ Banking Customer   │
└─────────┬──────────┘
          │
          ▼
┌────────────────────┐
│ React Chat UI      │
│ - User question    │
│ - AI response      │
│ - Sources          │
│ - Ticket status    │
└─────────┬──────────┘
          │ POST /chat
          ▼
┌────────────────────┐
│ FastAPI Backend    │
│ - Validation       │
│ - Session state    │
│ - Agent trigger    │
└─────────┬──────────┘
          ▼
┌────────────────────┐
│ Agent Orchestrator │
│ - Intent           │
│ - RAG              │
│ - Tool calls       │
│ - Verification     │
└────┬───────┬───────┘
     │       │
     ▼       ▼
┌────────┐ ┌──────────────┐
│ RAG    │ │ Banking Tools│
│ Docs   │ │ Mock APIs    │
└───┬────┘ └──────┬───────┘
    │             │
    ▼             ▼
┌────────────┐ ┌────────────┐
│ Vector DB  │ │ JSON Data  │
│ FAISS-ready│ │ Synthetic  │
└─────┬──────┘ └─────┬──────┘
      │              │
      └──────┬───────┘
             ▼
┌────────────────────┐
│ LLM Service        │
│ - Prompting        │
│ - Grounded answer  │
└─────────┬──────────┘
          ▼
┌────────────────────┐
│ Guardrails         │
│ - PII check        │
│ - Grounding check  │
│ - Confidence check │
└────┬─────────┬─────┘
     │         │
     ▼         ▼
 Answer    Support Ticket
```

## Runtime Flow

```text
User question
  ↓
React sends POST /chat
  ↓
FastAPI validates request
  ↓
Agent detects intent
  ↓
Retriever finds relevant policy chunks
  ↓
Tool node calls mock banking service if needed
  ↓
LLM service generates response
  ↓
Guardrails validate safety and grounding
  ↓
Return answer or create human handoff ticket
```
