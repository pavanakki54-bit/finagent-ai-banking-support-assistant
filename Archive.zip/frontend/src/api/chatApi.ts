export async function sendChat(message: string) {
  const response = await fetch('http://localhost:8000/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user_id: 'demo-user', message, payment_id: 'PAY-1001' })
  });
  if (!response.ok) throw new Error('Chat request failed');
  return response.json();
}
