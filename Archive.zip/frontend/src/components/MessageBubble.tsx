export function MessageBubble({ message }: { message: any }) {
  return <div className={`bubble ${message.role}`}>{message.text}</div>;
}
