export function SourcePanel({ sources }: { sources: any[] }) {
  if (!sources.length) return null;
  return <aside className="sources"><h3>Retrieved Sources</h3>{sources.map((s, i) => <p key={i}><b>{s.source}</b>: {s.text}</p>)}</aside>;
}
