export function EscalationBanner({ ticketId }: { ticketId: string }) {
  return <div className="handoff">Human handoff ticket created: {ticketId}</div>;
}
