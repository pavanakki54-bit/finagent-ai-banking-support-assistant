import { useState } from 'react';
import { sendChat } from '../api/chatApi';
import { MessageBubble } from './MessageBubble';
import { SourcePanel } from './SourcePanel';
import { EscalationBanner } from './EscalationBanner';

export function ChatWindow() {
  const [input, setInput] = useState('Why is my ACH payment delayed?');
  const [messages, setMessages] = useState<any[]>([]);
  const [sources, setSources] = useState<any[]>([]);
  const [handoff, setHandoff] = useState<any>(null);

  async function handleSend() {
    const userMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    const result = await sendChat(input);
    setMessages(prev => [...prev, { role: 'assistant', text: result.answer, meta: result }]);
    setSources(result.sources || []);
    setHandoff(result.handoff_required ? result : null);
  }

  return (
    <section className="chat-card">
      <div className="messages">
        {messages.map((m, i) => <MessageBubble key={i} message={m} />)}
      </div>
      <div className="input-row">
        <input value={input} onChange={e => setInput(e.target.value)} />
        <button onClick={handleSend}>Send</button>
      </div>
      {handoff && <EscalationBanner ticketId={handoff.ticket_id} />}
      <SourcePanel sources={sources} />
    </section>
  );
}
