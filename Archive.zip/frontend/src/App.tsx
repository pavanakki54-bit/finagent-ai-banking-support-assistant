import { ChatWindow } from './components/ChatWindow';

export default function App() {
  return (
    <main className="page">
      <section className="hero">
        <h1>FinAgent AI</h1>
        <p>Agentic AI Banking Support Assistant with RAG, tool calling, verification, and human handoff.</p>
      </section>
      <ChatWindow />
    </main>
  );
}
